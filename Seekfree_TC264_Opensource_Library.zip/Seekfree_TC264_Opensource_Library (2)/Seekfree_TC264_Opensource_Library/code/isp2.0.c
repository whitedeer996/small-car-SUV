/*
 * isp2.0.c
 *
 *  Created on: 2023��3��12��
 *      Author: mmj19
 */
#include "isp2.0.h"
#include "motor.h"
#include "servo.h"
#include "mpu6050used.h"

#define IPS200_TYPE     (IPS200_TYPE_PARALLEL8)           // ˫������ ���������� ����궨����д IPS200_TYPE_PARALLEL8
                                                          // �������� SPI ������ ����궨����д IPS200_TYPE_SPI
//  motor  servo

int Motor_PWM_Adjust = 6000;
unsigned char Read_Flash_index = 0;

void Isp_init(void)
{
    ips200_set_dir(IPS200_PORTAIT);
    ips200_set_color(RGB565_BLACK, RGB565_WHITE);
    ips200_init(IPS200_TYPE);
    ips200_set_font(IPS200_8X16_FONT);
    ips200_clear();

    ips200_show_string(0,2,"kp:");//ǰ���������� ���к���
    ips200_show_string(80,2,"ki:");//ǰ���������� ���к���
    ips200_show_string(160,2,"kd:");//ǰ���������� ���к���

    ips200_show_string(0,20,"servo_kp:");
    ips200_show_string(0,40,"servo_kd:");

    ips200_show_string(0,70,"longitude:");
    ips200_show_string(0,90,"latitude:");
    ips200_show_string(0,110,"azimuth:");
    ips200_show_string(0,130,"err_angle:");
    ips200_show_string(125,130,"yaw:");
    ips200_show_string(0,150,"just_yaw:");
    ips200_show_string(0,170,"Flash_Index:");
    ips200_show_string(0,190,"RunPoint_index:");


    ips200_show_string(0,210,"Sec_northangle_polish:");
    ips200_show_string(0,230,"sss_yaw_error[2]:");


    ips200_show_string(0,270,"Kp:");
    ips200_show_string(80,270,"Ki:");
    ips200_show_string(160,270,"Kd:");
    ips200_show_string(0,290,"Dis5:");
}

void Isp_menu_display(void)
{
    ips200_show_float(22,2,MPU6050PID_polish.Kp,2,3);//ǰ���������� ���к���
    ips200_show_float(102,2,MPU6050PID_polish.Ki,2,3);//ǰ���������� ���к���
    ips200_show_float(182,2,MPU6050PID_polish.Kd,2,3);//ǰ���������� ���к���

    ips200_show_float(76,20,ServoPID_polish.Kp,2,3);
    ips200_show_float(76,40,ServoPID_polish.Kd,2,3);

    ips200_show_float(85,70,Key_SavePoint[Read_Flash_index].longitude,3,6);
    ips200_show_float(80,90,Key_SavePoint[Read_Flash_index].latitude,3,6);
    ips200_show_float(65,110,azimuth_angle_filtering,3,6);
    ips200_show_float(76,130,error_angle,3,1);
    ips200_show_float(165,130,yaw_used,3,1);
    ips200_show_float(70,150,yaw_before_used_two_prase,3,1);
    ips200_show_int(95,170,Flash_Index,2);

    ips200_show_int(120,190,Tracing_Index,2);

    ips200_show_float(180,210,Second_northangle_polish,2,1);
    ips200_show_float(160,230,sss_yaw_error[2],2,1);

    ips200_show_float(22,270,ServoPID_polish_Demo.Kp,2,3);
    ips200_show_float(102,270,ServoPID_polish_Demo.Ki,2,3);
    ips200_show_float(182,270,ServoPID_polish_Demo.Kd,2,3);

    ips200_show_float(42,290,Common_Distance5,3,2);

}


void isp_display(float data1)
{
    ips200_show_float(121,2,data1,2,2);
}


void isp_line1()
{
    ips200_draw_line(0,0,0,60,RGB565_RED);//�Ϻ���
    ips200_draw_line(220,0,220,70,RGB565_RED);//������
    ips200_draw_line(0,0,220,0,RGB565_RED);//������
    ips200_draw_line(0,65,220,65,RGB565_RED);//�º���
}
void isp_line2()
{
    ips200_draw_line(0,70,0,120,RGB565_GREEN);  //������
    ips200_draw_line(220,70,220,140,RGB565_GREEN);//������
    ips200_draw_line(0,140,220,140,RGB565_GREEN);//�º���
}


//void isp_pid()
//{
//    isp_display0();
//    isp_display1(MotorPID_polish.Kp); //kp��ʾ
//    isp_display2(MotorPID_polish.Ki); //Ki��ʾ
//    isp_display3(MotorPID_polish.Kd); //kd��ʾ
//}

//void isp_gps1()
//{
//    ips200_show_string(2,70,isp_gpstring0);
//   // ips200_show_float(121,70,data1,2,2);
//}
//
//void isp_gps2(double data1)
//{
//    ips200_show_string(45,70,isp_gpstring1);
//    ips200_show_float(121,70,data1,2,2);
//}
//void isp_gps3(double data1)
//{
//    ips200_show_string(45,90,isp_gpstring2);
//    ips200_show_float(121,90,data1,2,2);
//}
//void isp_gps4(double data1)
//{
//    ips200_show_string(45,110,isp_gpstring3);
//    ips200_show_float(121,110,data1,2,2);
//}


//void isp_gpsplay()
//{
//    isp_gps1();
//    isp_gps2(0);
//    isp_gps3(0);
//    isp_gps4(0);
//    isp_line2();
//}
//
//
//char isp_mpustring0[] = " mpu:";
//char isp_mputring1[] = " yaw :";
//
//void isp_mpu1()
//{
//    ips200_show_string(2,160,isp_mpustring0);
//   // ips200_show_float(121,70,data1,2,2);
//}
//
//void isp_mpu2(double data1)
//{
//    ips200_show_string(45,160,isp_mputring1);
//    ips200_show_float(121,160,data1,2,2);
//}
//
//void isp_mpu()
//{
//    isp_mpu1();
//    isp_mpu2(0);
//}
