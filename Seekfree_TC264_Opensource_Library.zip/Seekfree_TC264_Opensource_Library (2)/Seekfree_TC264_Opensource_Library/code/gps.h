/*
 * gps.h
 *
 *  Created on: 2023��3��13��
 *      Author: mmj19
 */

#ifndef CODE_GPS_H_
#define CODE_GPS_H_

#include "zf_common_typedef.h"
#include "zf_device_gps_tau1201.h"
#include "pid.h"
#include "key.h"

typedef struct
{
    int index;
    double latitude;//γ��
    double longitude;
}gps_point;  // ����һ���ṹ�岢�����

extern unsigned char Flash_Index;
extern unsigned char SavePoint_Index;
extern unsigned char Tracing_Index;
extern unsigned char Turn_TracingFuction_Flag;

extern float Special_Distance1,Special_Distance2,Special_Distance3;
extern float Common_Distance2,Common_Distance5;
extern float Special_Azimuth0;

extern gps_point Key_SavePoint[30];//�ð����ɵ㣬������Ӧ������
extern gps_point Key_SpecialSavePoint[10];




void Flash_Key_SavePoint(void);
void SavePoint_function(void);
void Transmit_Flash_to_Key_SavePoint(void);
float Turn_GPSangle_to_180(gps_info_struct  *gps_tau1201);

uint8 Tracing(unsigned char index);
uint8 Tracing_SmallDistance(unsigned char index);



#endif /* CODE_GPS_H_ */
