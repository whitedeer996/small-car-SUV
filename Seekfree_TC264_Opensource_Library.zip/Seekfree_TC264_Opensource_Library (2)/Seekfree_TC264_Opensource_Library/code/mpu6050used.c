/*
 * icm20602.c
 *
 *  Created on: 2023��3��15��
 *      Author: mmj19
 */
#include "mpu6050used.h"
#include "gps.h"
#include "motor.h"
#include "isr.h"

#include "zf_driver_pit.h"
#include "zf_device_gps_tau1201.h"

#define Circle_Servo_Angle                    (140)
#define Circle_Servo_PWM                      ((uint32)SERVO_ANGLE_TO_DUTY(Circle_Servo_Angle))

double error_angle = 0.0;
double azimuth_angle = 0.0;
double azimuth_angle_adjust_to_north = 0.0,azimuth_angle_adjust_to_north1 = 0.0;
double azimuth_angle_filtering = 0.0;

float yaw_used = 0.0;
float yaw_before_used_one_prase = 0.0;
float yaw_before_used_two_prase = 0.0,yaw_before_used_two_prase_before = 0.0;
unsigned char Turn_second_part_Flag = 0;
unsigned char BUG_Flag = 0;

unsigned char circle_angle_Flag = 0;
unsigned char sss_angle_Flag = 0;
unsigned char turn_between_twostate_Flag = 0;
float  circle_yaw_error[3] = {0,0,0},sss_yaw_error[3] = {0,0,0},guding_yaw_error[3] = {0,0,0};//��һ��ֱ����ĩ���̶����
unsigned char Element_Run_Turn = 0;   //Ԫ���ܱ�־λ
unsigned char GudingDajiao_Flag = 0;  //��һ��ֱ����ĩ���̶���Ǳ�־λ

float Second_northangle_polish = 0.0;//������Ļ�������β����汱�ǣ�ʵ��û�õ���

float pitch=0,roll=0,yaw=0;
short aacx=0,aacy=0,aacz=0;           //���ٶȴ�����ԭʼ����
short gyrox=0,gyroy=0,gyroz=0;        //������ԭʼ����

unsigned char sss_Count0 = 0,sss_Count1 = 0;
unsigned char sss_Count0_Flag = 0,sss_Count1_Flag = 0;

PID_TypeDef MPU6050PID_polish;


void MPU6050PID_Init(void)
{
    MPU6050PID_polish.Kp = 2.7;//3  2.8
    MPU6050PID_polish.Kd = 0.45;//0.3  0.43  0.48
    MPU6050PID_polish.Ki = 0.16;//0.1
}




double get_two_points_azimuth_to_180(gps_info_struct  *gps_tau1201,gps_point *SavePoint)
{
    double rlatitude,rlongitude,slatitude,slongitude;//r:ʵʱ s:��֪
    rlatitude = ANGLE_TO_RAD(gps_tau1201->latitude);
    slatitude = ANGLE_TO_RAD(SavePoint->latitude);
    rlongitude = ANGLE_TO_RAD(gps_tau1201->longitude);
    slongitude = ANGLE_TO_RAD(SavePoint->longitude);

    double x = sin(slongitude - rlongitude) * cos(slatitude);
    double y = cos(rlatitude) * sin(slatitude) - sin(rlatitude) * cos(slatitude) * cos(slongitude - rlongitude);
    double angle = RAD_TO_ANGLE(atan2(x, y));
    angle = ((angle > 0) ? angle : (angle + 360));

    if( angle <= 180)
        return angle;
    else
        return (angle-360);
}//�������ã�ʹ�÷�λ�Ƿ�Χ��������ƫ���Ƿ�Χһ��[ -180,180]\
   ע��㣺������˳��\
          �ڷ�λ�ǵĵױ�ȷ���� N==0 ������

double Azimuth_SlidingMedianFilter(double new_data)
{
    static double AzimuthBuf[5] = {0.0};

    double res = 0.0;

    for(int16_t i = 0;i < 4 ;i++)
    {
        AzimuthBuf[i] = AzimuthBuf[i + 1];
    }

    AzimuthBuf[4] = new_data;

    for(int16_t i = 0;i < 5 ;i++)
    {
        res += AzimuthBuf[i];
    }

    return res / 5.0;

}//=====================�˲��㷨

double Azimuth_SlidingMedianFilter_AA(double new_data)
{
    static double AzimuthBuf_AA[5] = {0.0};

    double res_AA = 0.0;

    for(int16_t i = 0;i < 4 ;i++)
    {
        AzimuthBuf_AA[i] = AzimuthBuf_AA[i + 1];
    }

    AzimuthBuf_AA[4] = new_data;

    for(int16_t i = 0;i < 5 ;i++)
    {
        res_AA += AzimuthBuf_AA[i];
    }

    return res_AA / 5.0;

}//=====================�˲��㷨

double Error_Angle(float mpu6050_yaw,unsigned char index)
{
    azimuth_angle = get_two_points_azimuth_to_180(&gps_tau1201,&Key_SavePoint[index]);  //�õ���ʵʱ��

    azimuth_angle_filtering = Azimuth_SlidingMedianFilter(azimuth_angle);

    if( fabs((double)mpu6050_yaw - azimuth_angle_filtering) <= 180 )
    {
      return   ((double)mpu6050_yaw - azimuth_angle_filtering)   ;
    }
    else
    {
      if( (double)mpu6050_yaw - azimuth_angle_filtering < 0)
          return   ((double)mpu6050_yaw - azimuth_angle_filtering + 360)   ;
      else
          return   ((double)mpu6050_yaw - azimuth_angle_filtering - 360)   ;
    }

}//����


void Latest_ErrorAngle(void)
{
    error_angle = Error_Angle(yaw_used,Tracing_Index);

}//���� while ����ã�ʵʱ����   ErrorAngle


void Circle_Element_Runing(void)
{

    Special_Distance1 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[0].latitude,Key_SpecialSavePoint[0].longitude);
    Special_Distance2 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[1].latitude,Key_SpecialSavePoint[1].longitude);
    Special_Distance3 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[2].latitude,Key_SpecialSavePoint[2].longitude);
//    Special_Azimuth0 = get_two_points_azimuth (gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[0].latitude,Key_SpecialSavePoint[0].longitude);
//    Distance1 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,32.344276,119.394440);
//    Distance2 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,32.344303,119.394440);
//    Distance3 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,32.344246,119.394447);

    if(Special_Distance1 <= 6 && Special_Distance1 <= 10.0)//5  7
    {
         if(Down_SpeedFlag0 == 0)
         {
             Down_SpeedFlag0 = 1;
             MotorSetPwmValue(-2500);//2500
         }

         if(fabs(Special_Distance2-Special_Distance3)< 2.8 )//2  2.7
         {

           turn_between_twostate_Flag = 1;
           circle_angle_Flag = 1;
//           MotorSetPwmValue(-2500);
         }
    }

    if(circle_angle_Flag == 1)
    {

         if(yaw_used>=0)
          {
             circle_yaw_error[0]=yaw_used;
          }
          if(yaw_used<0)
          {
              circle_yaw_error[0]=-yaw_used;
          }
          if(circle_yaw_error[1]==0)
          {
              circle_yaw_error[1]=circle_yaw_error[0];
          }
          circle_yaw_error[2]=circle_yaw_error[2]+fabs(circle_yaw_error[0]-circle_yaw_error[1]);
          circle_yaw_error[1]=circle_yaw_error[0];


          if(circle_yaw_error[2] <= 250)
          {
              Circle_RunStart(1,114);
          }
          else
          {
              circle_angle_Flag = 0;//ת��Ȧ��
              turn_between_twostate_Flag = 0;//Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
              Element_Run_Turn = 1;//�л���S��Ԫ��
//              MotorSetPwmValue(-6000);//ת��Ȧ�ˣ���ʼ����
              MotorSetPwmValue(-3500);//ת��Ȧ�ˣ���ʼ����

          }
    }




}


void Circle_RunStart(int circle_direct,int servo_angle)
{
    if(circle_direct == 0)
      pwm_set_duty(ATOM0_CH1_P33_9, (uint32)SERVO_ANGLE_TO_DUTY(servo_angle));// ʵʱ���¶��pwm��ռ�ձ� SERVO_L_MAX
    else
      pwm_set_duty(ATOM0_CH1_P33_9, (uint32)SERVO_ANGLE_TO_DUTY(servo_angle));// ʵʱ���¶��pwm��ռ�ձ�
}

//void Circle_Element_Runing(void)
//{
//    if(circle_angle_Flag == 1)
//    {
//        if(yaw_error[0] >= 0)
//            circle_angle += yaw_error[0];
//        else
//            circle_angle = circle_angle -yaw_error[0];
//
//        if(circle_angle >= 330)
//        {
//            circle_angle_Flag = 0;
//            circle_angle = 0;
//        }
//    }
//
//    AzimuthAngle_Special_1 = get_two_points_azimuth_to_180(&gps_tau1201,&Key_SpecialSavePoint[0]);
//    AzimuthAngle_Special_2 = get_two_points_azimuth_to_180(&gps_tau1201,&Key_SpecialSavePoint[1]);
//    Distance_Special_1 = get_two_points_distance(Key_SavePoint[2].latitude,Key_SavePoint[2].longitude,gps_tau1201.latitude,gps_tau1201.longitude);
//    if( (AzimuthAngle_Special_1 <= -70 && AzimuthAngle_Special_1 >= -110) && (AzimuthAngle_Special_2 <= 110 && AzimuthAngle_Special_2 >= 70) && (Distance_Special_1 <= 2) )
//    {
//        circle_angle_Flag = 1;
//        Circle_RunStart();
//    }
//}
//
//void Circle_RunStart(void)
//{
//    pwm_set_duty(ATOM0_CH1_P33_9, Circle_Servo_PWM);// ʵʱ���¶��pwm��ռ�ձ�
//
//}


void SSS_Element_Runing(void)
{
    static float Distance1,Distance2,Distance3;
    Distance1 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[3].latitude,Key_SpecialSavePoint[3].longitude);
    Distance2 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[4].latitude,Key_SpecialSavePoint[4].longitude);
    Distance3 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[5].latitude,Key_SpecialSavePoint[5].longitude);

    if(Distance1 <= 6 && Distance2 <= 10.0 )//5  6  7
    {
         if(Down_SpeedFlag2 == 0)
         {
             Down_SpeedFlag2 = 1;
             MotorSetPwmValue(-2700);
         }
         if(fabs(Distance2-Distance3) < 2.0)//2  2.2 3.2  �� 2.9��
         {
           MotorSetPwmValue(-2150);
           turn_between_twostate_Flag = 1;
           sss_angle_Flag = 1;
         }
//         if(fabs(Distance2-Distance3) < 2.8)//2  2.2
//         {
//           turn_between_twostate_Flag = 1;
//           sss_angle_Flag = 1;
//         }
     }
    if(sss_angle_Flag == 1)
    {
         if(yaw_used>=0)
          {
             sss_yaw_error[0]=yaw_used;
          }
          if(yaw_used<0)
          {
              sss_yaw_error[0]=-yaw_used;
          }
          if(sss_yaw_error[1]==0)
          {
              sss_yaw_error[1]=sss_yaw_error[0];
          }
          sss_yaw_error[2]=sss_yaw_error[2]+fabs(sss_yaw_error[0]-sss_yaw_error[1]);
          sss_yaw_error[1]=sss_yaw_error[0];

          if(sss_yaw_error[2] <= 90)
          {
              Circle_RunStart(1,103);//��ת
          }
          if(sss_yaw_error[2] > 90 && sss_yaw_error[2] <= 250)
          {
              MotorSetPwmValue(-2500);
              Circle_RunStart(0,170);//��ת
          }
          if(sss_yaw_error[2] > 250 && sss_yaw_error[2] <= 290)
          {
              MotorSetPwmValue(-3000);
              Circle_RunStart(0,170);//��ת
          }
          if(sss_yaw_error[2] > 290  &&  sss_yaw_error[2] <= 490)
          {
               Circle_RunStart(0,103);//��ת
          }
          if(sss_yaw_error[2] >= 490)
          {
              sss_angle_Flag = 0;//����S��Ԫ��
              MotorSetPwmValue(-7000);//��ʼ����
              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
          }

//          if(sss_yaw_error[2] <= 65)
//          {
//              Circle_RunStart(0,168);//0��ת
//          }
//          if(sss_yaw_error[2] > 65 && sss_yaw_error[2] <= 200)
//          {
//              MotorSetPwmValue(-3000);
//              Circle_RunStart(1,103);//1��ת
//          }
//          if(sss_yaw_error[2] >= 200 )
//          {
//               Circle_RunStart(0,175);//��ת
//          }
//          if(sss_yaw_error[2] >= 280)
//          {
//              sss_angle_Flag = 0;//����S��Ԫ��
//              MotorSetPwmValue(-8000);//��ʼ����
//              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
//          }

//          if(sss_yaw_error[2] <= 65 && sss_Count0_Flag == 0)
//          {
//              Beep_ON();
//              Circle_RunStart(0,168);//0��ת
//          }
//          else if(sss_Count1_Flag != 1)
//          {
//              Beep_OFF();
//              sss_Count0_Flag = 1;
//              sss_Count0++;
//              Circle_RunStart(0,136.5);//ֱ��һ��ʱ�䣨���룩
//          }
//
//          if(sss_Count0 >= 25 && sss_Count1_Flag == 0)
//          {
//              sss_Count0 = 30;
//              sss_yaw_error[2] = 0;//ֱ��һ��ʱ�䣨���룩�������ۼ�
//              sss_Count1_Flag = 1;
//          }
//
//          if(sss_yaw_error[2] <= 135 && sss_Count0_Flag == 1 && sss_Count1_Flag == 1)
//          {
//              MotorSetPwmValue(-3200);
//              Circle_RunStart(1,103);//1��ת
//          }
//          else if(sss_Count1_Flag == 1)
//          {
//              sss_Count1++;
//              Circle_RunStart(0,136.5);//ֱ��һ��ʱ�䣨���룩
//          }
//
//          if(sss_Count1 >= 5 && sss_Count1_Flag!= 2)
//          {
//              sss_Count1 = 0;
//              sss_Count1_Flag = 2;
//          }
//          if(sss_Count1_Flag == 2)
//          {
//              sss_angle_Flag = 0;//����S��Ԫ��
//              MotorSetPwmValue(-8000);//��ʼ����
//              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
//          }





//          if(sss_yaw_error[2] > 65 && sss_yaw_error[2] <= 200)
//          {
//              MotorSetPwmValue(-3200);
//              Circle_RunStart(1,103);//1��ת
//          }
//          if(sss_yaw_error[2] >= 200 )
//          {
//               Circle_RunStart(0,175);//��ת
//          }
//          if(sss_yaw_error[2] >= 280)
//          {
//              sss_angle_Flag = 0;//����S��Ԫ��
//              MotorSetPwmValue(-8000);//��ʼ����
//              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
//          }

    }




}


void GudingDajiao_Runing(void)
{
    if(GudingDajiao_Flag == 0) {GudingDajiao_Flag = 1;turn_between_twostate_Flag = 1; Beep_ON();}

    if(GudingDajiao_Flag == 1)
    {
         if(yaw_used>=0)
          {
             guding_yaw_error[0]=yaw_used;
          }
          if(yaw_used<0)
          {
              guding_yaw_error[0]=-yaw_used;
          }
          if(guding_yaw_error[1]==0)
          {
              guding_yaw_error[1]=guding_yaw_error[0];
          }
          guding_yaw_error[2]=guding_yaw_error[2]+fabs(guding_yaw_error[0]-guding_yaw_error[1]);
          guding_yaw_error[1]=guding_yaw_error[0];


          if(guding_yaw_error[2] >= 165)
          {
              GudingDajiao_Flag = 2;//������ͷ��guding�����
              Beep_OFF();
              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
          }
          else
          {
              Circle_RunStart(0,161);//����116
          }

    }

}

unsigned char D_value_first = 0,D_value_last = 0;
void SSS_Element_Runing_otherproject(void)
{
    static float Distance1,Distance2,Distance3;
    Distance1 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[3].latitude,Key_SpecialSavePoint[3].longitude);
    Distance2 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[4].latitude,Key_SpecialSavePoint[4].longitude);
    Distance3 = get_two_points_distance(gps_tau1201.latitude,gps_tau1201.longitude,Key_SpecialSavePoint[5].latitude,Key_SpecialSavePoint[5].longitude);

    if(Distance1 <= 6 && Distance2 <= 10.0 && sss_angle_Flag == 0)//5  6  7
    {
         if(Down_SpeedFlag2 == 0)
         {
             Down_SpeedFlag2 = 1;
             MotorSetPwmValue(-2700);
         }
         if(fabs(Distance2-Distance3) < 2.0)//2  2.2 3.2  �� 2.9��
         {
           MotorSetPwmValue(-2150);
           turn_between_twostate_Flag = 1;
           D_value_first = Tracing_Index;
           Turn_TracingFuction_Flag = 1;
           sss_angle_Flag = 1;
        }
     }

    if(sss_angle_Flag == 1)
    {
          ServoControl_icm_angle(error_angle);
          D_value_last = Tracing_Index;
          if( (D_value_last - D_value_first) >= 3)
          {
              sss_angle_Flag = 2;//����S��Ԫ��
              Turn_TracingFuction_Flag = 0;
              MotorSetPwmValue(-4000);//��ʼ����
              turn_between_twostate_Flag = 0;////Ԫ���ܺ�Ѳ���ܵ�ģʽ״̬�л�
          }
    }
}
