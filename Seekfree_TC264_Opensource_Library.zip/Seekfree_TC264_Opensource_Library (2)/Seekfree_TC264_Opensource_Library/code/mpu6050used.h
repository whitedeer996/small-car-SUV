/*
 * icm20602.h
 *
 *  Created on: 2023��3��15��
 *      Author: mmj19
 */

#ifndef CODE_MPU6050USED_H_
#define CODE_MPU6050USED_H_


#include "isr.h"
#include "gps.h"


extern float yaw_used;
extern float yaw_before_used_one_prase;
extern float yaw_before_used_two_prase,yaw_before_used_two_prase_before;
extern unsigned char Turn_second_part_Flag;
extern unsigned char BUG_Flag;

extern unsigned char circle_angle_Flag;
extern unsigned char sss_angle_Flag;
extern unsigned char turn_between_twostate_Flag;
extern float  circle_yaw_error[3],sss_yaw_error[3];

extern unsigned char Element_Run_Turn;
extern unsigned char GudingDajiao_Flag;

extern float pitch,roll,yaw;
extern short aacx,aacy,aacz;           //���ٶȴ�����ԭʼ����
extern short gyrox,gyroy,gyroz;        //������ԭʼ����

extern double error_angle;
extern double azimuth_angle;
extern double azimuth_angle_adjust_to_north,azimuth_angle_adjust_to_north1;
extern double azimuth_angle_filtering;

extern unsigned char sss_Count0,sss_Count1;
extern unsigned char sss_Count0_Flag,sss_Count1_Flag;

extern PID_TypeDef MPU6050PID_polish;

extern float Second_northangle_polish;

void MPU6050PID_Init(void);
double get_two_points_azimuth_to_180(gps_info_struct  *gps_tau1201,gps_point *SavePoint);

double Error_Angle(float mpu6050_yaw,unsigned char index);
void Latest_ErrorAngle(void);
void Circle_Element_Runing(void);
void Circle_RunStart(int circle_direct,int servo_angle);
void SSS_Element_Runing(void);
void SSS_Element_Runing_otherproject(void);
void GudingDajiao_Runing(void);

void pit_hanlder (void);
void icm20602_user_init(void);
double Azimuth_SlidingMedianFilter(double new_data);
double Azimuth_SlidingMedianFilter_AA(double new_data);


#endif /* CODE_MPU6050USED_H_ */
