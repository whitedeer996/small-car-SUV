/*
 * motor.h
 *
 *  Created on: 2023��3��1��
 *      Author: mmj19
 */

#ifndef CODE_MOTOR_H_
#define CODE_MOTOR_H_

#include "zf_common_typedef.h"
#include "pid.h"




void MotorInit(void);// �����ʼ��
void MotorSetPwmValue(int32 PwmValue);
int32 Motor_GetSpeed(void);

float MotorControl(float targetSpeed);//2-5ms  ���� TIM12-5ms �ж���
void Wireless_uart_Park_Function(void);

extern unsigned char Up_SpeedFlag0,Up_SpeedFlag1;
extern unsigned char Down_SpeedFlag0,Down_SpeedFlag1,Down_SpeedFlag2;
extern unsigned char Park_Flag;
extern unsigned char StartRun_Flag;
extern unsigned char StartRun_Count;
extern unsigned char Wireless_uart_ParkFlag;
extern PID_TypeDef MotorPID_polish;

#endif /* CODE_MOTOR_H_ */
