/*
 * wireless_uart.h
 *
 *  Created on: 2023��3��8��
 *      Author: mmj19
 */

#ifndef CODE_WIRELESS_UART_H_
#define CODE_WIRELESS_UART_H_

#include "zf_common_headfile.h"
#include "zf_common_fifo.h"


#define UART_INDEX              (WIRELESS_UART_INDEX   )                           // UART_2
#define UART_BAUDRATE           (WIRELESS_UART_BUAD_RATE)                          // 115200
#define UART_TX_PIN             (WIRELESS_UART_TX_PIN  )                           // UART2_RX_P10_6
#define UART_RX_PIN             (WIRELESS_UART_RX_PIN  )                           // UART2_TX_P10_5


void Wireless_uart_Init(void);
void Wireless_uart_printf(char *fmt,...);
void LED_Init(void);

#endif /* CODE_WIRELESS_UART_H_ */
