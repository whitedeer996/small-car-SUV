/*
 * isp2.0.h
 *
 *  Created on: 2023��3��12��
 *      Author: mmj19
 */

#ifndef CODE_ISP2_0_H_
#define CODE_ISP2_0_H_

#include "zf_common_headfile.h"


extern int Motor_PWM_Adjust ;
extern unsigned char Read_Flash_index;

void Isp_init(void);
void Isp_menu_display(void);

void isp_display(float data1);
void isp_line1(void);
void isp_line2(void);

#endif /* CODE_ISP2_0_H_ */
